package cpw.mods.fml.common.modloader;

public interface IModLoaderSidedHelper
{

    void finishModLoading(ModLoaderModContainer mc);

}
